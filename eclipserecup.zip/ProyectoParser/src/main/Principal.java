package main;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import other.Parser;

public class Principal {

	public static void main(String[] args) {
		
		Parser parser = new Parser();
		
		try {
			parsearFich(parser);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	private static void parsearFich(Parser parser) throws ParserConfigurationException, SAXException, IOException {
		parser.parseFicherosXml("biblioteca.xml");
		parser.parseDocument();
		parser.printLibro();
		
	}

}
