package other;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Parser {
	private Document dom = null;
	private ArrayList<Libro> libros = null;
	
	public Parser() {
		libros = new ArrayList<Libro>();
	}
	
	public void parseFicherosXml(String fichero) throws ParserConfigurationException, SAXException, IOException{
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		
		InputStream is = new FileInputStream(fichero);
		Reader rd = new InputStreamReader(is, "UTF-8");
		InputSource isrc = new InputSource(rd);
		isrc.setEncoding("UTF-8");
		
		dom = db.parse(isrc);
	}
	
	public void parseDocument() {
		
		Element doc = dom.getDocumentElement();
		NodeList nl = doc.getElementsByTagName("libro");
		
		if (nl != null && nl.getLength() > 0 ) {
			for (int i = 0; i< nl.getLength(); i++) {
				Element e1 = (Element)  nl.item(i);
				Libro l = getLibro(e1);
				libros.add(l);
			}
		}
	}
	

	private Libro getLibro(Element libro) {
		
		String editor = getTextValue(libro,"editor");
		String titulo = getTextValue(libro,"titulo");
		String pags = getTextValue(libro,"paginas");
		String anyo = getAributeValue(libro,"titulo");
		String valoracion = getTextValue(libro,"valoracion");
		
		NodeList autores = libro.getElementsByTagName("nombre");
		String lista = "";
		
		for (int i =0; i < autores.getLength(); i++) {
			Element e = (Element) autores.item(i);
			if (i == 0) {
				lista = lista + e.getFirstChild().getNodeValue();
			}else {
			lista = lista + " , " + e.getFirstChild().getNodeValue();
			}
		}
		lista = lista + " ";
		
		Libro l1 = new Libro();
		l1.setAnyo(anyo);
        l1.setEditor(editor);
        l1.setPaginas(pags);
        l1.setTitulo(titulo);
        l1.setAutor(lista);
        l1.setValoracion(valoracion);
		return l1;
	}

	private String getAributeValue(Element libro, String string) {
		
		String valor = null;
		NodeList nl = libro.getElementsByTagName(string);
		
		if (nl != null && nl.getLength()>0) {
			Element e1 = (Element)nl.item(0);
			valor = e1.getAttribute("anyo");
		}
		
		return valor;
	}

	private String getTextValue(Element libro, String string) {
		String valor = null;
		NodeList nl = libro.getElementsByTagName(string);
		
		if (nl != null && nl.getLength() > 0) {
			Element e1 = (Element) nl.item(0);
			valor = e1.getFirstChild().getNodeValue();
		}
		return valor;
	}
	
	public void printLibro() {
		Iterator<Libro> it = libros.iterator();
		StringBuilder sb = new StringBuilder();
		
		while(it.hasNext()) {
			Libro l = it.next();
			sb.append(l.toString() + "\n");
			
		}
		System.out.println(sb);
	}

}
