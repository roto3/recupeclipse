package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import model.*;
import view.*;

public class GestionEventos {

	private GestionDatos model;
	private LaunchView view;
	private ActionListener actionListener_comparar, actionListener_buscar, actionListener_guardar, actionListener_recuperar, actionListener_recTodos, actionListener_cuentapal;

	public GestionEventos(GestionDatos model, LaunchView view) {
		this.model = model;
		this.view = view;
	}

	public void contol() {
		actionListener_cuentapal= new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				
				int cont = call_contarPalabra();
				
					if (cont != 0) {
						view.getTextArea().setText("El texto tiene "+cont+" palabras.");
					
					}else view.getTextArea().setText("El texto est� vac�o");
				}
			};
			view.getCuentapal().addActionListener(actionListener_cuentapal);
		actionListener_comparar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				// TODO: Llamar a la funci�n call_compararContenido
				if (call_compararContenido() == 1) {
					view.getTextArea().setText("Los ficheros son iguales");
				}else {
					view.getTextArea().setText("Los ficheros no son iguales.");
				}
			}
		};
		view.getComparar().addActionListener(actionListener_comparar);

		actionListener_buscar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				// TODO: Llamar a la funci�n call_buscarPalabra
				int cont = call_buscarPalabra();
				if (cont != 0) {
					view.getTextArea().setText("La palabra se ha encontrado en la l�nea "+cont);
				
				}else view.getTextArea().setText("La palabra no se ha encontrado.");
			}
		};
		view.getBuscar().addActionListener(actionListener_buscar);
		
		actionListener_guardar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				call_guardar();
				
			}
			
		};
		view.getBtnGuardarFichero().addActionListener(actionListener_guardar);
		
		actionListener_recuperar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				Libro libro = call_recuperar();
				view.getTextArea().setText("Libro: "+libro);
				
			}
			
		};
		view.getBtnRecuperarLibro().addActionListener(actionListener_recuperar);
		
		actionListener_recTodos = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				ArrayList<String> arraylst = call_recuperar_todos();
				Iterator<String> it = arraylst.iterator();
				
				while(it.hasNext()) {
					String f = it.next();
					view.getTextArea().setText(f+" ");
				}
				
			}
			
		};
		view.getBtnRecuperarTodos().addActionListener(actionListener_recTodos);
		
		
	}

	private int call_compararContenido() {

		String fich1 = "";
		String fich2 = "";
		int compara = 0;
		
		fich1 = view.getFichero1().getText();
		fich2 = view.getFichero2().getText();
		
		try {
			if (model.compararContenido(fich1, fich2)) {
				compara = 1;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.print("No se encuentra al menos uno de los archivos");
		}
		
		// TODO: Llamar a la funci�n compararContenido de GestionDatos
		// TODO: Gestionar excepciones
		return compara;
	}

	private int call_buscarPalabra() {

		String palabra = view.getPalabra().getText();
		String fichero = view.getFichero1().getText();
		boolean primer = view.isPrimera().isSelected();
		
		int cont = 0;
		
		try {
			cont = model.buscarPalabra(fichero, palabra, primer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO: Llamar a la funci�n buscarPalabra de GestionDatos
		// TODO: Gestionar excepciones
		return cont;
	}
	
	private int call_contarPalabra() {

		String fichero = view.getFichero1().getText();
		
		int cont = 0;
		
		try {
			cont = model.contarPalabra(fichero);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO: Llamar a la funci�n buscarPalabra de GestionDatos
		// TODO: Gestionar excepciones
		return cont;
	}
	
	public void call_guardar() {
		String id = view.getjTextFieldID().getText();
		String titulo = view.getjTextFieldTit().getText();
	    String autor = view.getjTextFieldAutor().getText();
		String editor = view.getjTextFieldEdit().getText();
		String anyo = view.getjTextFieldAnyo().getText();
		String pags = view.getjTextFieldNumPag().getText();
		
		Libro libro = new Libro(id,titulo,autor,editor,anyo,pags);
		
		try {
		model.guardar_libro(libro);
		} catch (IOException e) {
			view.showError("Error de I/O.");
		}
		
	}
	
	public Libro call_recuperar() {
		Libro libro = null;
		
		try {
			String id = view.getjTextFieldID().getText();
			libro = model.recuperar(id);
		} catch (ClassNotFoundException ex ) {
			// TODO Auto-generated catch block
			view.showError("No se encuentra la clase GestionDatos o Libro");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return libro;
		
	}
	public ArrayList<String> call_recuperar_todos(){
		return model.recuperar_todos();
	}

}
