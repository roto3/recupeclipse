package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Mmmmm extends JFrame {

	private JButton comparar,buscar, cuentapal;
	private JTextArea textArea;
	private JTextField fichero1,fichero2,palabra;
	private JLabel label_f1,label_f2,label_pal;
	private JCheckBox primera;
	
	private JPanel panel;
	
	private JButton btnGuardarFichero;
	private JButton btnRecuperarLibro;
	private JButton btnRecuperarTodos;
	private JLabel lblTtulo;
	private JTextField jTextFieldTit;
	private JLabel lblIdentificador;
	private JTextField jTextFieldID;
	private JLabel lblEditor;
	private JTextField jTextFieldEdit;
	private JLabel lblAutor;
	private JTextField jTextFieldAutor;
	private JLabel lblNmeroDePginas;
	private JTextField jTextFieldNumPag;
	private JLabel lblNewLabel;
	private JTextField jTextFieldAnyo;
	
	public Mmmmm() {
		
		setBounds(200,200,1000,450);
		setTitle("Proyecto Buffers");	
		panel = new JPanel();
		
		comparar = new JButton("Comparar contenido");
		comparar.setPreferredSize(new Dimension(150, 26));
		buscar = new JButton("Buscar palabra");
		buscar.setPreferredSize(new Dimension(150, 26));
		cuentapal= new JButton("Cuenta palabras");
		cuentapal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cuentapal.setPreferredSize(new Dimension(150, 26));
					
		fichero1 = new JTextField("",10);
		fichero2 = new JTextField("",10);
		palabra = new JTextField("",10);
		
		label_f1 = new JLabel("Fichero 1:");
		label_f2 = new JLabel("Fichero 2:");
		label_pal = new JLabel("Palabra:");
		
		primera = new JCheckBox("Primera aparici�n");

		textArea = new JTextArea(20, 80);
		textArea.setBounds(50,50,50,50);
		textArea.setEditable(false);		
		
		panel.add(comparar);
		panel.add(buscar);
		panel.add(cuentapal);
		panel.add(label_f1);
		panel.add(fichero1);
		panel.add(label_f2);
		panel.add(fichero2);
		panel.add(label_pal);
		panel.add(palabra);
		panel.add(primera);
		panel.add(textArea);
		
        // A�adimos el JPanel al JFrame
		this.getContentPane().add(panel);

        lblTtulo = new JLabel("T\u00EDtulo:");
        panel.add(lblTtulo);

        jTextFieldTit = new JTextField();
        panel.add(jTextFieldTit);
        jTextFieldTit.setColumns(10);

        lblIdentificador = new JLabel("Identificador:");
        panel.add(lblIdentificador);

        jTextFieldID = new JTextField();
        panel.add(jTextFieldID);
        jTextFieldID.setColumns(10);

        lblEditor = new JLabel("Editor:");
        panel.add(lblEditor);

        jTextFieldEdit = new JTextField();
        panel.add(jTextFieldEdit);
        jTextFieldEdit.setColumns(10);

        lblAutor = new JLabel("Autor:");
        panel.add(lblAutor);

        jTextFieldAutor = new JTextField();
        panel.add(jTextFieldAutor);
        jTextFieldAutor.setColumns(10);

        lblNmeroDePginas = new JLabel("N\u00FAmero de p\u00E1ginas:");
        panel.add(lblNmeroDePginas);

        jTextFieldNumPag = new JTextField();
        panel.add(jTextFieldNumPag);
        jTextFieldNumPag.setColumns(10);

        lblNewLabel = new JLabel("A\u00F1o de publicaci\u00F3n: ");
        panel.add(lblNewLabel);

        jTextFieldAnyo = new JTextField();
        panel.add(jTextFieldAnyo);
        jTextFieldAnyo.setColumns(10);

        btnGuardarFichero = new JButton("Guardar libro");
        panel.add(btnGuardarFichero);

        btnRecuperarLibro = new JButton("Recuperar libro");
        panel.add(btnRecuperarLibro);

        btnRecuperarTodos = new JButton("Recuperar todos");
        panel.add(btnRecuperarTodos);

	}	

	public JButton getComparar() {
		return comparar;
	}

	public void setComparar(JButton comparar) {
		this.comparar = comparar;
	}

	public JButton getBuscar() {
		return buscar;
	}

	public void setBuscar(JButton buscar) {
		this.buscar = buscar;
	}
	public JButton getCuentapal() {
		return cuentapal;
	}

	public void setCuentapal(JButton cuentapal) {
		this.cuentapal = cuentapal;
	}

	public JTextArea getTextArea() {
		return textArea;
	}

	public void setTextArea(JTextArea textArea) {
		this.textArea = textArea;
	}

	public JTextField getFichero1() {
		return fichero1;
	}

	public void setFichero1(JTextField fichero1) {
		this.fichero1 = fichero1;
	}

	public JTextField getFichero2() {
		return fichero2;
	}

	public void setFichero2(JTextField fichero2) {
		this.fichero2 = fichero2;
	}

	public void setPrimera(JCheckBox primera) {
		this.primera = primera;
	}

	public JCheckBox isPrimera() {
		return primera;
	}

	public void showError(String m){
		JOptionPane.showMessageDialog(this.panel,
			    m,
			    "Error",
			    JOptionPane.ERROR_MESSAGE);
	}

	public JTextField getPalabra() {
		return palabra;
	}

	public void setPalabra(JTextField palabra) {
		this.palabra = palabra;
	}

	public JButton getBtnGuardarFichero() {
		return btnGuardarFichero;
	}

	public void setBtnGuardarFichero(JButton btnGuardarFichero) {
		this.btnGuardarFichero = btnGuardarFichero;
	}

	public JButton getBtnRecuperarLibro() {
		return btnRecuperarLibro;
	}

	public void setBtnRecuperarLibro(JButton btnRecuperarLibro) {
		this.btnRecuperarLibro = btnRecuperarLibro;
	}

	public JButton getBtnRecuperarTodos() {
		return btnRecuperarTodos;
	}

	public void setBtnRecuperarTodos(JButton btnRecuperarTodos) {
		this.btnRecuperarTodos = btnRecuperarTodos;
	}

	public JTextField getjTextFieldTit() {
		return jTextFieldTit;
	}

	public void setjTextFieldTit(JTextField jTextFieldTit) {
		this.jTextFieldTit = jTextFieldTit;
	}

	public JTextField getjTextFieldID() {
		return jTextFieldID;
	}

	public void setjTextFieldID(JTextField jTextFieldID) {
		this.jTextFieldID = jTextFieldID;
	}

	public JTextField getjTextFieldEdit() {
		return jTextFieldEdit;
	}

	public void setjTextFieldEdit(JTextField jTextFieldEdit) {
		this.jTextFieldEdit = jTextFieldEdit;
	}

	public JTextField getjTextFieldAutor() {
		return jTextFieldAutor;
	}

	public void setjTextFieldAutor(JTextField jTextFieldAutor) {
		this.jTextFieldAutor = jTextFieldAutor;
	}

	public JTextField getjTextFieldNumPag() {
		return jTextFieldNumPag;
	}

	public void setjTextFieldNumPag(JTextField jTextFieldNumPag) {
		this.jTextFieldNumPag = jTextFieldNumPag;
	}

	public JTextField getjTextFieldAnyo() {
		return jTextFieldAnyo;
	}

	public void setjTextFieldAnyo(JTextField jTextFieldAnyo) {
		this.jTextFieldAnyo = jTextFieldAnyo;
	}


}