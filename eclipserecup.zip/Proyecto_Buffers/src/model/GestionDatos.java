package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class GestionDatos {

	public GestionDatos() {

	}

	//TODO: Implementa una funci�n para abrir ficheros
	
	public BufferedReader abreFich(String fichero) throws IOException {
		
		FileReader fr = new FileReader(fichero);
		
		BufferedReader br = new BufferedReader(fr);

		return br;
}
	
	//TODO: Implementa una funci�n para cerrar ficheros
	
	public void cierraFich(BufferedReader br) throws IOException{
		
		br.close();
	
	}
	
	public boolean compararContenido (String fichero1, String fichero2) throws IOException{
		//TODO: Implementa la funci�n
		String strfich1 = "";
		String strfich2 = "";
		String temp1 = "";
		String temp2 = "";
		
		Boolean igu = false;
		
		BufferedReader br1 = abreFich(fichero1);
		BufferedReader br2 = abreFich(fichero2);
		
		while((strfich1 = br1.readLine()) != null){
			temp1 = temp1+strfich1;
		}
		while((strfich2 = br2.readLine()) != null){
			temp2 = temp2+strfich2;
		}
		
		if (temp2.compareTo(temp1) == 0) {
			igu = true;
		}
		
		cierraFich(br1);
		cierraFich(br2);
		
		return igu;
	}
	
	public int buscarPalabra (String fichero1, String palabra, boolean primera_aparicion) throws IOException{
		//TODO: Implementa la funci�n
		
		BufferedReader br = abreFich(fichero1);
		String pal = "";
		String temp = "";
		int cont = 0;
		int ulti = 0;
		int primi = 0;
		
	while((pal = br.readLine()) != null) {
		temp = pal;
		cont++;
		
		if(temp.compareTo(palabra)==0) {
			ulti = cont;
			if (primi == 0 && primera_aparicion == true) {
				primi = cont;
			}
		}
	}
		cierraFich(br);
		
		if (primera_aparicion == true) {
			return primi;
		}else {
			return ulti;
		}
		
	}

	public void guardar_libro(Libro libro) throws IOException  {
		String id = libro.getId();
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(id + ".txt"));
		oos.writeObject(libro);
		
		oos.close();
		
	}

	public Libro recuperar(String id) throws IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(id));
		Libro libro = (Libro) ois.readObject();
		
		ois.close();
		
		return libro;
	}	
	
	public ArrayList<String> recuperar_todos(){
		File carpeta = new File("").getAbsoluteFile();
		File[] lista = carpeta.listFiles();
		ArrayList<String> libros = new ArrayList<>();
		
		for (int i=0; i<lista.length; i++) {
			String s = lista[i].getName().substring(lista[i].getName().lastIndexOf(".")+1);
			if (s=="txt") {
				libros.add(lista[i].getName());
			}
		}
		
		return libros;
		
	}

	public int contarPalabra(String fichero) throws IOException{
			
			BufferedReader br = abreFich(fichero);
			String pal = "";
			String aux ="";
			char esp = ' ';
			int cont = 0;
			
		while((pal = br.readLine()) != null) {
			aux = pal;
			for(int i=0;i<aux.length();i++) {
				if(aux.charAt(i)==(esp)) {
				cont++;
			}
			System.out.println("hola");
			
		}
			cierraFich(br);
			
	}
		return cont;

}
}
